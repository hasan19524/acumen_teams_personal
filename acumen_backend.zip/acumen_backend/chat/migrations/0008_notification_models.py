# chat/migrations/0008_notification_models.py
# NEW FILE: Migration for Notification and NotificationPreference models

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        (
            "workspaces",
            "0002_workspace_description_workspace_logo_teammembership_and_more",
        ),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("chat", "0007_dmrequest_block_report"),
    ]

    operations = [
        migrations.CreateModel(
            name="Notification",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "notification_type",
                    models.CharField(
                        choices=[
                            ("dm_request", "DM Request"),
                            ("dm_request_accepted", "DM Request Accepted"),
                            ("mention", "Mention"),
                            ("channel_invite", "Channel Invite"),
                            ("block_created", "Block Created"),
                            ("task_assigned", "Task Assigned"),
                        ],
                        max_length=50,
                    ),
                ),
                ("related_object_id", models.IntegerField(blank=True, null=True)),
                ("title", models.CharField(max_length=200)),
                ("description", models.TextField(blank=True)),
                (
                    "status",
                    models.CharField(
                        choices=[
                            ("unread", "Unread"),
                            ("read", "Read"),
                            ("archived", "Archived"),
                        ],
                        default="unread",
                        max_length=20,
                    ),
                ),
                ("metadata", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("read_at", models.DateTimeField(blank=True, null=True)),
                (
                    "actor",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="notifications_sent",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "recipient",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="notifications",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "workspace",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="notifications",
                        to="workspaces.workspace",
                    ),
                ),
            ],
            options={
                "ordering": ["-created_at"],
            },
        ),
        migrations.CreateModel(
            name="NotificationPreference",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("dm_requests_enabled", models.BooleanField(default=True)),
                ("mentions_enabled", models.BooleanField(default=True)),
                ("channel_invites_enabled", models.BooleanField(default=True)),
                ("task_assignments_enabled", models.BooleanField(default=True)),
                ("all_notifications_muted", models.BooleanField(default=False)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "user",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="notification_preferences",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
        ),
        migrations.AddIndex(
            model_name="notification",
            index=models.Index(
                fields=["recipient", "workspace", "status"],
                name="chat_notifi_recipie_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="notification",
            index=models.Index(
                fields=["recipient", "-created_at"], name="chat_notifi_recipie_idx2"
            ),
        ),
    ]
